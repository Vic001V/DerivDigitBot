package com.muya.derivbot

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var bot: DerivBot
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var log: TextView
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); stats=findViewById(R.id.stats); log=findViewById(R.id.log)
        findViewById<Button>(R.id.start).setOnClickListener { startBot() }
        findViewById<Button>(R.id.stop).setOnClickListener { if (::bot.isInitialized) bot.stop(); status.text="Status: stopped" }
    }
    private fun startBot() {
        bot.stop()
        val real=findViewById<Switch>(R.id.realMode).isChecked
        if(real){
            android.app.AlertDialog.Builder(this).setTitle("Real-money trading")
                .setMessage("This can place real trades. Continue only if you understand the risk.")
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Enable"){_,_-> launchBot(real) }.show()
        } else launchBot(false)
    }
    private fun launchBot(real:Boolean) {
        bot=DerivBot(
            appId=findViewById<EditText>(R.id.appId).text.toString().trim(),
            accountId=findViewById<EditText>(R.id.accountId).text.toString().trim(),
            token=findViewById<EditText>(R.id.token).text.toString().trim(),
            symbol=findViewById<EditText>(R.id.symbol).text.toString().trim(),
            currency=findViewById<EditText>(R.id.currency).text.toString().trim().uppercase(),
            stake=findViewById<EditText>(R.id.stake).text.toString().toDoubleOrNull() ?: 1.0,
            minConfidence=findViewById<EditText>(R.id.minConfidence).text.toString().toDoubleOrNull() ?: 60.0,
            maxLosses=findViewById<EditText>(R.id.maxLosses).text.toString().toIntOrNull() ?: 3,
            real=real,
            onStatus={s -> runOnUiThread{status.text="Status: $s"}},
            onStats={s -> runOnUiThread{stats.text=s}},
            onLog={s -> runOnUiThread{log.text=(s+"\n"+log.text).take(5000)}})
        bot.start()
    }
    override fun onDestroy(){ bot.stop(); scope.cancel(); super.onDestroy() }
}

class DerivBot(private val appId:String, private val accountId:String, private val token:String, private val symbol:String, private val currency:String, private val stake:Double, private val minConfidence:Double, private val maxLosses:Int, private val real:Boolean, private val onStatus:(String)->Unit, private val onStats:(String)->Unit, private val onLog:(String)->Unit) {
    private val client=OkHttpClient.Builder().readTimeout(0,TimeUnit.MILLISECONDS).build(); private var ws:WebSocket?=null; private var stopped=true; private var req=10
    private val digits=ArrayDeque<Int>(); private var wins=0; private var losses=0; private var consecutiveLosses=0; private var pending=false
    fun start(){ stopped=false; if(appId.isBlank() || accountId.isBlank() || token.isBlank() || symbol.isBlank() || currency.isBlank()){ onStatus("missing credentials/settings"); onLog("Enter App ID, Account ID, PAT, currency and symbol."); stopped=true; return }; onStatus("requesting secure WebSocket session"); CoroutineScope(Dispatchers.IO).launch { try { val url=getOtpUrl(); connect(url) } catch(e:Exception){ onStatus("error"); onLog("Auth error: ${e.message}") } } }
    fun stop(){ stopped=true; ws?.close(1000,"user stop"); ws=null; pending=false }
    private fun getOtpUrl():String { val base="https://api.derivws.com/trading/v1/options/accounts/$accountId/otp"; val req=Request.Builder().url(base).post(okhttp3.RequestBody.create(null,ByteArray(0))).addHeader("Authorization","Bearer $token").addHeader("Deriv-App-ID",appId).build(); client.newCall(req).execute().use{ r-> val body=r.body?.string()?:(throw Exception("empty OTP response")); if(!r.isSuccessful) throw Exception(body); return JSONObject(body).getJSONObject("data").getString("url") } }
    private fun connect(url:String){ ws=client.newWebSocket(Request.Builder().url(url).build(),object:WebSocketListener(){ override fun onOpen(w:WebSocket,response:Response){ onStatus(if(real)"connected REAL" else "connected DEMO"); send(mapOf("ticks" to symbol,"subscribe" to 1,"req_id" to next())) }
        override fun onMessage(w:WebSocket,text:String){ handle(text) }
        override fun onFailure(w:WebSocket,t:Throwable,r:Response?){ if(!stopped){ onStatus("connection failed"); onLog("Socket error: ${t.message}") } }
    }) }
    private fun next()=req++
    private fun send(map:Map<String,Any>){ ws?.send(JSONObject(map).toString()) }
    private fun handle(raw:String){ try { val o=JSONObject(raw); when(o.optString("msg_type")){ "tick"->onTick(o); "proposal"->onProposal(o); "buy"->onBuy(o); "proposal_open_contract"->onContract(o); "error"->onLog("Deriv error: "+o.optJSONObject("error")?.optString("message")) } }catch(e:Exception){ onLog("Parse error: ${e.message}") } }
    private fun onTick(o:JSONObject){ val q=o.getJSONObject("tick").getString("quote"); val d=q.filter{it.isDigit()}.lastOrNull()?.digitToInt() ?: return; digits.addLast(d); if(digits.size>100)digits.removeFirst(); val over=digits.count{it>=4}.toDouble()/digits.size*100; val under=digits.count{it<=3}.toDouble()/digits.size*100; onStats("Wins: $wins  Losses: $losses\nLast digit: $d\nOver 3 empirical: ${"%.1f".format(over)}%\nUnder 4 empirical: ${"%.1f".format(under)}%\nSignal: "+if(over>=minConfidence && over>under)"OVER 3" else if(under>=minConfidence && under>over)"UNDER 4" else "WAIT")
        if(!pending && digits.size>=30 && consecutiveLosses<maxLosses){ if(over>=minConfidence && over>under) requestProposal("DIGITOVER","3") else if(under>=minConfidence && under>over) requestProposal("DIGITUNDER","4") }
    }
    private fun requestProposal(type:String,barrier:String){ pending=true; onLog("Signal: $type barrier $barrier"); send(mapOf("proposal" to 1,"amount" to stake,"basis" to "stake","contract_type" to type,"currency" to currency,"duration" to 1,"duration_unit" to "t","barrier" to barrier,"underlying_symbol" to symbol,"req_id" to next())) }
    private fun onProposal(o:JSONObject){ val p=o.optJSONObject("proposal")?:return; val id=p.optString("id"); val ask=p.optString("ask_price").toDoubleOrNull()?:stake; if(id.isNotEmpty()) send(mapOf("buy" to id,"price" to ask,"req_id" to next())) else { pending=false; onLog("No proposal ID") } }
    private fun onBuy(o:JSONObject){ val b=o.optJSONObject("buy")?:return; val id=b.optLong("contract_id",0); onLog("Bought contract $id for ${b.optString("buy_price")}"); if(id>0) send(mapOf("proposal_open_contract" to 1,"contract_id" to id,"subscribe" to 1,"req_id" to next())) }
    private fun onContract(o:JSONObject){ val c=o.optJSONObject("proposal_open_contract")?:return; if(c.optBoolean("is_sold",false)){ val profit=c.optString("profit").toDoubleOrNull()?:0.0; if(profit>0){wins++; consecutiveLosses=0}else{losses++; consecutiveLosses++}; pending=false; onLog("Result: ${if(profit>0)"WIN" else "LOSS"} profit=$profit"); onStats("Wins: $wins  Losses: $losses\nWin rate: "+if(wins+losses==0)"0" else "%.1f".format(wins*100.0/(wins+losses))+"%\nConsecutive losses: $consecutiveLosses"); if(consecutiveLosses>=maxLosses) onStatus("stopped: loss limit reached") } }
}
