# Deriv Digit Bot — Android phone build

This is a native Android MVP for Deriv **DIGITOVER (Over 3)** and **DIGITUNDER (Under 4)** contracts.

## Important
- Demo mode is the default.
- No 99% win-rate guarantee is made; the app reports observed results.
- Never paste your Deriv password into the app. It uses a Personal Access Token (PAT).
- The PAT should have only the permissions required for trading and can be revoked in Deriv.
- Real-money mode is deliberately protected by a confirmation dialog.

## Build directly on Android
The included source is intended to be opened in an Android Gradle IDE such as AndroidIDE. AndroidIDE is no longer maintained, so use it only from a trusted release source and understand that compatibility can vary.

1. Install AndroidIDE from a trusted source such as its GitHub Releases or F-Droid.
2. Download and extract this ZIP to your phone.
3. In AndroidIDE choose **Open existing project** and select the `DerivDigitBot` folder.
4. Allow Gradle to sync and install the requested Android SDK/build tools if prompted.
5. Build `app` → `assembleDebug`.
6. Install the resulting APK from `app/build/outputs/apk/debug/app-debug.apk`.

AndroidIDE supports Gradle-based Android projects on Android devices and includes an SDK manager/terminal. Its upstream project is archived, so it is not a maintained IDE.

## Deriv connection
The app uses Deriv's current REST + WebSocket Options API flow:
1. PAT + App ID authenticate the REST OTP request.
2. The OTP endpoint returns a short-lived authenticated WebSocket URL.
3. The app connects to the demo or real socket selected by the account ID.
4. It requests DIGITOVER/DIGITUNDER proposals and buys the returned proposal.

Use a demo account first.

## Fields
- App ID: your Deriv application ID
- Account ID: the Options trading account ID
- Personal Access Token: scoped PAT with trading permission
- Currency: account currency, e.g. USD
- Symbol: an active Deriv symbol supporting digit contracts
- Stake: amount per trade
- Minimum signal confidence: empirical threshold used by this MVP
- Maximum consecutive losses: automatic stop limit

## Strategy limitation
This MVP uses recent observed last-digit frequency as a signal. That is not proof of future outcomes and is not a guaranteed predictive edge. Before using real funds, run a substantial demo test and review the actual win rate, payout, drawdowns, and contract availability.
